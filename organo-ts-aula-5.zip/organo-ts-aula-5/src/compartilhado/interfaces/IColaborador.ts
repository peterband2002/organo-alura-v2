export interface IColaborador {
    nome: string
    cargo: string
    imagem: string
    time?: string
    data: string
}